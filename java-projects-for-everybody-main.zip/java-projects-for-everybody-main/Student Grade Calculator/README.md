# Student Grade Calculator
This Java program calculates and displays the average grades for a group of students.

## Features
- Input student names and their respective grades
- Calculate the average grade
- Display a report with each student's name and grade, along with the overall average grade

## Usage
1. Launch the program.
2. Enter the number of students.
3. For each student, enter their name and grade.
4. The program will calculate the average grade and display a report with each student's name and grade, along with the overall average grade.

## Contributing
Contributions are welcome! If you have any suggestions or improvements, please feel free to submit a pull request.

## Credits
This project was created by Kalutu Daniel.



